@extends('admin.layout')

@php($isEditing = isset($product))

@section('title', $isEditing ? 'Edit product' : 'Add product')
@section('heading', $isEditing ? 'Edit product' : 'Add product')

@section('content')
    <section class="max-w-3xl">
        <form method="POST"
              action="{{ $isEditing ? route('admin.products.update', $product) : route('admin.products.store') }}"
              enctype="multipart/form-data"
              class="flex flex-col gap-6 rounded-2xl border border-[#e1e1d8] bg-white p-5 shadow-sm sm:p-8">
            @csrf
            @if ($isEditing)
                @method('PUT')
            @endif

            <div class="flex flex-col gap-2">
                <label for="name" class="text-sm font-bold">Product name</label>
                <input id="name" name="name" type="text" value="{{ old('name', $product->name ?? '') }}" maxlength="255" required
                       class="w-full rounded-xl border border-[#d6d7ce] px-4 py-3 outline-none transition focus:border-[#49a32d] focus:ring-4 focus:ring-[#49a32d]/10">
                @error('name') <p class="text-sm font-medium text-red-700">{{ $message }}</p> @enderror
            </div>

            <div class="flex flex-col gap-2">
                <label for="description" class="text-sm font-bold">Description</label>
                <textarea id="description" name="description" rows="5" maxlength="10000" required
                          class="w-full resize-y rounded-xl border border-[#d6d7ce] px-4 py-3 outline-none transition focus:border-[#49a32d] focus:ring-4 focus:ring-[#49a32d]/10">{{ old('description', $product->description ?? '') }}</textarea>
                @error('description') <p class="text-sm font-medium text-red-700">{{ $message }}</p> @enderror
            </div>

            <div class="flex flex-col gap-3">
                <label for="image" class="text-sm font-bold">Product image {{ $isEditing ? '(optional)' : '' }}</label>
                @if ($isEditing)
                    <img src="{{ $product->imageUrl() }}" alt="Current image for {{ $product->name }}" class="h-36 w-52 rounded-xl bg-[#f3f2ed] object-cover">
                @endif
                <input id="image" name="image" type="file" accept=".jpg,.jpeg,.png,.webp" {{ $isEditing ? '' : 'required' }}
                       class="w-full rounded-xl border border-dashed border-[#c8c9c0] bg-[#fafaf7] px-4 py-3 text-sm file:mr-4 file:rounded-lg file:border-0 file:bg-[#eaf2e6] file:px-3 file:py-2 file:font-bold file:text-[#347a24]">
                <p class="text-xs text-[#777972]">JPG, PNG or WebP, up to 5 MB.</p>
                @error('image') <p class="text-sm font-medium text-red-700">{{ $message }}</p> @enderror
            </div>

            <div class="flex flex-wrap justify-end gap-3 border-t border-[#eeeeea] pt-5">
                <a href="{{ route('admin.products.index') }}" class="rounded-xl border border-[#d6d7ce] px-5 py-3 font-semibold transition hover:bg-[#f8f8f4]">Cancel</a>
                <button type="submit" class="rounded-xl bg-[#17251b] px-5 py-3 font-bold text-white transition hover:bg-[#263b2b]">{{ $isEditing ? 'Save changes' : 'Create product' }}</button>
            </div>
        </form>
    </section>
@endsection
