<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="theme-color" content="#17251b">
    <title>Admin sign in | Arbo</title>
    @vite(['resources/css/app.css', 'resources/js/app.js'])
</head>
<body class="grid min-h-screen place-items-center bg-[#f3f2ed] px-4 py-10 text-[#20231f]">
    <main class="w-full max-w-md rounded-3xl border border-[#e3e3da] bg-white p-7 shadow-xl shadow-[#17251b]/5 sm:p-9">
        <a href="{{ url('/') }}" class="flex items-center gap-3 text-xl font-bold tracking-wide">
            <span class="grid h-10 w-10 place-items-center rounded-xl bg-[#17251b] text-lg text-white">A</span>
            Arbo Admin
        </a>

        <div class="mt-8 flex flex-col gap-2">
            <p class="text-xs font-bold uppercase tracking-[0.18em] text-[#49a32d]">Secure access</p>
            <h1 class="text-3xl font-bold tracking-tight">Sign in</h1>
            <p class="text-sm leading-6 text-[#777972]">Manage products and team members for the Arbo website.</p>
        </div>

        <form method="POST" action="{{ route('admin.login.store') }}" class="mt-7 flex flex-col gap-5">
            @csrf
            <div class="flex flex-col gap-2">
                <label for="email" class="text-sm font-semibold">Email address</label>
                <input id="email" name="email" type="email" value="{{ old('email') }}" autocomplete="username" required autofocus
                       class="w-full rounded-xl border border-[#d6d7ce] bg-white px-4 py-3 outline-none transition focus:border-[#49a32d] focus:ring-4 focus:ring-[#49a32d]/10">
                @error('email')
                    <p class="text-sm font-medium text-red-700">{{ $message }}</p>
                @enderror
            </div>

            <div class="flex flex-col gap-2">
                <label for="password" class="text-sm font-semibold">Password</label>
                <input id="password" name="password" type="password" autocomplete="current-password" required
                       class="w-full rounded-xl border border-[#d6d7ce] bg-white px-4 py-3 outline-none transition focus:border-[#49a32d] focus:ring-4 focus:ring-[#49a32d]/10">
            </div>

            <button type="submit" class="mt-1 rounded-xl bg-[#17251b] px-5 py-3 font-bold text-white transition hover:bg-[#263b2b] focus:outline-none focus:ring-4 focus:ring-[#49a32d]/30">
                Sign in to admin
            </button>
        </form>
    </main>
</body>
</html>
